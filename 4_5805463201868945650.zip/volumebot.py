import os
import random
import asyncio
import logging
import json
import base64
from typing import Optional
from dataclasses import dataclass
from dotenv import load_dotenv
import aiohttp
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    ContextTypes,
    CommandHandler
)
from solana.rpc.async_api import AsyncClient
from solana.transaction import Transaction
from solana.keypair import Keypair
from solana.publickey import PublicKey
from solana.rpc.types import TokenAccountOpts

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Environment configuration
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
RPC_ENDPOINT = os.getenv("SOLANA_RPC_ENDPOINT", "https://api.mainnet-beta.solana.com")
PUMP_FUN_URL = os.getenv("PUMP_FUN_API", "https://api.pump.fun")
SOLFLARE_KEYPAIR_PATH = os.getenv("SOLFLARE_KEYPAIR_PATH")

# Trading configuration
@dataclass
class TradingConfig:
    wallet: Optional[Keypair] = None
    buy_probability: float = 0.8
    sell_probability: float = 0.2
    min_amount: float = 0.01
    max_buy_amount: float = 1.5
    max_sell_amount: float = 0.08
    loop_delay: int = 60
    loop_active: bool = False
    dry_run: bool = False

CONFIG = TradingConfig()

# Fixed token mint
TARGET_TOKEN_MINT = PublicKey("H6s6CWBxWuNhzpRb3bWCbZtxqzPZ3G9ZdfUFZPqcpump")

async def load_wallet_from_env() -> Optional[Keypair]:
    """Load wallet from environment-configured path"""
    if not SOLFLARE_KEYPAIR_PATH:
        return None
    try:
        with open(SOLFLARE_KEYPAIR_PATH, 'r') as f:
            data = json.load(f)
        return Keypair.from_secret_key(bytes(data))
    except Exception as e:
        logger.error("Wallet loading failed: %s", e)
        return None

async def get_token_balance(client: AsyncClient, owner: PublicKey) -> float:
    """Get current token balance for configured mint"""
    try:
        resp = await client.get_token_accounts_by_owner(
            owner, 
            TokenAccountOpts(mint=TARGET_TOKEN_MINT)
            )
        balance = 0.0
        for acct in resp['result']['value']:
            info = acct['account']['data']['parsed']['info']
            amount = int(info['tokenAmount']['amount'])
            decimals = int(info['tokenAmount']['decimals'])
            balance += amount / (10 ** decimals)
        return balance
    except Exception as e:
        logger.error("Balance check failed: %s", e)
        return 0.0

async def perform_swap(client: AsyncClient, amount: float, buy: bool) -> Optional[str]:
    """Execute swap using pump.fun API with aiohttp"""
    if not CONFIG.wallet or CONFIG.dry_run:
        return None

    async with aiohttp.ClientSession() as session:
        try:
            payload = {
                "wallet": str(CONFIG.wallet.public_key),
                "tokenMint": str(TARGET_TOKEN_MINT),
                "amountSol": amount,
                "side": "buy" if buy else "sell"
            }
            
            async with session.post(
                f"{PUMP_FUN_URL}/v1/swap",
                json=payload,
                timeout=10
            ) as resp:
                resp.raise_for_status()
                data = await resp.json()
                
                tx_bytes = base64.b64decode(data["transactionBase64"])
                tx = Transaction.deserialize(tx_bytes)
                result = await client.send_transaction(tx, CONFIG.wallet)
                return result['result']
                
        except Exception as e:
            logger.error("Swap failed: %s", e)
            raise

async def trading_loop(chat_id: int, context: ContextTypes.DEFAULT_TYPE):
    """Main trading loop with error handling and retries"""
    client = AsyncClient(RPC_ENDPOINT)
    consecutive_errors = 0
    max_retries = 5

    try:
        while CONFIG.loop_active:
            try:
                # Generate random trade decision
                is_buy = random.random() < CONFIG.buy_probability
                amount = round(random.uniform(
                    CONFIG.min_amount,
                    CONFIG.max_buy_amount if is_buy else CONFIG.max_sell_amount
                ), 6)

                # Execute or simulate trade
                if CONFIG.dry_run:
                    msg = f"DRY RUN: Would {'buy' if is_buy else 'sell'} {amount} SOL"
                else:
                    sig = await perform_swap(client, amount, is_buy)
                    msg = f"Trade executed: {'Buy' if is_buy else 'Sell'} {amount} SOL\nTx: {sig}"

                await context.bot.send_message(chat_id=chat_id, text=msg)
                consecutive_errors = 0

            except Exception as e:
                consecutive_errors += 1
                logger.error("Trading error (%d/%d): %s", 
                             consecutive_errors, max_retries, e)
                
                if consecutive_errors >= max_retries:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text="⚠️ Multiple errors detected. Stopping trading loop."
                    )
                    break

                await asyncio.sleep(CONFIG.loop_delay * 2)  # Backoff

            await asyncio.sleep(CONFIG.loop_delay)

    finally:
        CONFIG.loop_active = False
        await client.close()
        logger.info("Trading loop stopped")

# Telegram command handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Initial command with safety warnings"""
    text = (
        "🚀 *Solana Trading Bot*\n\n"
        "⚠️ *WARNING*\n"
        "- Live trading with real funds\n"
        "- Configure carefully\n"
        "- Test with /dry_run first\n\n"
        "Use /help for commands"
    )
    await update.message.reply_markdown(text)

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List available commands"""
    await update.message.reply_text(
        "🛠 Available Commands:\n"
        "/start - Welcome message\n"
        "/status - Show wallet/token balances\n"
        "/dry_run - Toggle simulation mode\n"
        "/set_probs <buy> <sell> - Set probabilities\n"
        "/start_loop - Begin auto trading\n"
        "/stop_loop - Stop auto trading\n"
        "/help - Show this message"
    )

async def set_probs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set buy/sell probabilities"""
    if len(context.args) != 2:
        return await update.message.reply_text("Usage: /set_probs <buy> <sell> (0-1)")
    
    try:
        buy, sell = map(float, context.args)
        if not (0 <= buy <= 1 and 0 <= sell <= 1):
            raise ValueError
        
        CONFIG.buy_probability = buy
        CONFIG.sell_probability = sell
        await update.message.reply_text(
            f"✅ Probabilities updated\nBuy: {buy:.2f}\nSell: {sell:.2f}"
        )
    except Exception:
        await update.message.reply_text("❌ Invalid values. Use numbers between 0 and 1")

async def toggle_dry_run(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Toggle simulation mode"""
    CONFIG.dry_run = not CONFIG.dry_run
    state = "ENABLED" if CONFIG.dry_run else "DISABLED"
    await update.message.reply_text(f"🛡️ Dry run mode: {state}")

async def start_loop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start the automated trading loop"""
    if not CONFIG.wallet:
        await update.message.reply_text("❌ Wallet not loaded. Use .env config.")
        return

    if CONFIG.loop_active:
        await update.message.reply_text("⚠️ Trading loop already running")
        return

    CONFIG.loop_active = True
    asyncio.create_task(trading_loop(update.effective_chat.id, context))
    await update.message.reply_text(
        f"🚀 Trading loop started\n"
        f"Buy Prob: {CONFIG.buy_probability:.2f}\n"
        f"Sell Prob: {CONFIG.sell_probability:.2f}\n"
        f"Interval: {CONFIG.loop_delay}s"
    )

async def stop_loop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Stop the automated trading loop"""
    if not CONFIG.loop_active:
        await update.message.reply_text("ℹ️ No active trading loop")
        return

    CONFIG.loop_active = False
    await update.message.reply_text("🛑 Trading loop stopped")
    
async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show current configuration and balances"""
    if not CONFIG.wallet:
        return await update.message.reply_text("❌ Wallet not loaded")
    
    async with AsyncClient(RPC_ENDPOINT) as client:
        try:
            sol_balance = (await client.get_balance(CONFIG.wallet.public_key))['result']['value'] / 1e9
            token_balance = await get_token_balance(client, CONFIG.wallet.public_key)
        except Exception as e:
            logger.error("Status check failed: %s", e)
            return await update.message.reply_text("❌ Failed to fetch balances")

    text = (
        "📊 *Current Status*\n"
        f"SOL Balance: {sol_balance:.4f}\n"
        f"Token Balance: {token_balance:.4f}\n"
        f"Buy Probability: {CONFIG.buy_probability:.2f}\n"
        f"Sell Probability: {CONFIG.sell_probability:.2f}\n"
        f"Loop Active: {'✅' if CONFIG.loop_active else '❌'}\n"
        f"Dry Run: {'✅' if CONFIG.dry_run else '❌'}"
    )
    await update.message.reply_markdown(text)

def register_handlers(app):
    """Register all Telegram command handlers"""
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("dry_run", toggle_dry_run))
    app.add_handler(CommandHandler("set_probs", set_probs))
    app.add_handler(CommandHandler("start_loop", start_loop))
    app.add_handler(CommandHandler("stop_loop", stop_loop))

async def main():
    """Main application setup"""
    CONFIG.wallet = await load_wallet_from_env()
    
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    register_handlers(app)
    
    if CONFIG.wallet:
        logger.info("Wallet loaded successfully")
    else:
        logger.warning("No wallet configured")
    
    await app.run_polling()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested")