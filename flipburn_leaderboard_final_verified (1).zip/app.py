# Main Flask app for leaderboard
from flask import Flask, render_template, jsonify
app = Flask(__name__)

@app.route('/')
def home():
    return '🔥 Flip Burn Bot is LIVE'

@app.route('/leaderboard')
def leaderboard():
    data = [{'wallet': '4eTWY...3q2N', 'total_burned': 125.5, 'last_burn': '2025-04-23 16:05'}]
    return render_template('leaderboard.html', leaderboard=data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
